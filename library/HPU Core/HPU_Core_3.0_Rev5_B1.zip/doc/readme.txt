----------------------------------------------
Head Processor Unit Core for iCub Applications
----------------------------------------------
