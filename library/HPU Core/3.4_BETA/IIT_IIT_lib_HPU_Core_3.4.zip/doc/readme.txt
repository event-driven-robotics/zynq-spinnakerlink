----------------------------------------------
Head Processor Unit Core for iCub Applications
----------------------------------------------

It offers an interface to 
- AER Devices
- PAER Devices
- SpiNNaker
